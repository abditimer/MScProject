package demos.gui.uicomponents;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/ui/Spinner.fxml", title = "Material Design Example")
public class SpinnerController {

}
