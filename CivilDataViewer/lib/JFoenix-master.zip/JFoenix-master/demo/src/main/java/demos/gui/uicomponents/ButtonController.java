package demos.gui.uicomponents;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/ui/Button.fxml", title = "Material Design Example")
public class ButtonController {

}
